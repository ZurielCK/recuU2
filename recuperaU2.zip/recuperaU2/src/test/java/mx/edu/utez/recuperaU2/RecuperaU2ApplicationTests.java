package mx.edu.utez.recuperaU2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecuperaU2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
