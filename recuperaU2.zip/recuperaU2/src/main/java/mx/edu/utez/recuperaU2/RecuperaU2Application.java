package mx.edu.utez.recuperaU2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecuperaU2Application {

	public static void main(String[] args) {
		SpringApplication.run(RecuperaU2Application.class, args);
	}

}
